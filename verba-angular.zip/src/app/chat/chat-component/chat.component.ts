import { Component } from '@angular/core';

@Component({
  selector: 'app-chat-component',
  standalone: true,
  imports: [],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.scss'
})
export class ChatComponent {

}
