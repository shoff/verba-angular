import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes } from '@angular/router';

const _routes: Routes = [
  { path: 'chat', loadChildren: () => import('./chat/chat.module').then(m => m.ChatModule) },
  { path: '', redirectTo: 'chat', pathMatch: 'full' },  // Redirect root to /chat
  { path: '**', redirectTo: 'chat' }  // Redirect any unmatched paths to /chat
];

export const routes = _routes;

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class AppRoutingModule { }
